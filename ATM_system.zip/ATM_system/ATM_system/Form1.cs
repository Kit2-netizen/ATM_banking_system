﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace ATM_system
{
    
    public partial class Form1 : Form
    {
        static string acc_name;
        static string acc_pin;
        static float acc_bal;
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection("Data Source=localhost;Initial Catalog=Bank;Integrated Security=True");   //sql connection 
        DataTable dt = new DataTable();
        private void button13_Click(object sender, EventArgs e)
        {
            lbl_value.Text = "";
        }

        private void button38_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button43_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
        }

        private void button42_Click(object sender, EventArgs e)
        {
            comboBox3.Items.Clear();
            
            
            txtdeposit.Text = "";
            
        }

        private void button44_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void button41_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage5;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (
                lbl_value.Text == "")
                lbl_value.Text = ("1");
            else
                lbl_value.Text = lbl_value.Text + "1";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (
               lbl_value.Text == "")
                lbl_value.Text = ("2");
            else
                lbl_value.Text = lbl_value.Text + "2";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (
               lbl_value.Text == "")
                lbl_value.Text = ("3");
            else
                lbl_value.Text = lbl_value.Text + "3";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (
               lbl_value.Text == "")
                lbl_value.Text = ("4");
            else
                lbl_value.Text = lbl_value.Text + "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (
               lbl_value.Text == "")
                lbl_value.Text = ("5");
            else
                lbl_value.Text = lbl_value.Text + "5";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (
               lbl_value.Text == "")
                lbl_value.Text = ("6");
            else
                lbl_value.Text = lbl_value.Text + "6";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (
               lbl_value.Text == "")
                lbl_value.Text = ("7");
            else
                lbl_value.Text = lbl_value.Text + "7";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (
               lbl_value.Text == "")
                lbl_value.Text = ("8");
            else
                lbl_value.Text = lbl_value.Text + "8";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (
               lbl_value.Text == "")
                lbl_value.Text = ("9");
            else
                lbl_value.Text = lbl_value.Text + "9";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (
               lbl_value.Text == "")
                lbl_value.Text = ("0");
            else
                lbl_value.Text = lbl_value.Text + "0";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            lbl_value.Text = "";
        }

        private void button15_Click(object sender, EventArgs e)
        {
            string value = lbl_value.Text;

            
            try
            {
                string query = ("SELECT *FROM Accounts WHERE Pin='" + value + "'");
                SqlDataAdapter adp = new SqlDataAdapter(query, conn);
                adp.Fill(dt);

                if (dt.Rows.Count == 1)
                {
                    acc_name = dt.Rows[0]["Acc_name"].ToString();
                    acc_bal = float.Parse(dt.Rows[0]["Acc_Balance"].ToString());

                    lblaccname.Text = acc_name;
                    lblaccbalance.Text = acc_bal.ToString();
                    lbln.Text = acc_name;
                    lblb.Text = acc_bal.ToString();


                    radioButton1.Enabled = true;
                    radioButton2.Enabled = true;
                    radioButton3.Enabled = true;
                    radioButton4.Enabled = true;
                    radioButton5.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Nope.Try Again", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            radioButton1.Enabled = false;
            radioButton2.Enabled = false;
            radioButton3.Enabled = false;
            radioButton4.Enabled = false;
            radioButton5.Enabled = false;
        }

        private void button35_Click(object sender, EventArgs e)
        {
           
            string actype = comboactype.Text;
            

            
          
            if (comboactype.Text == "")
            {

                ep.Clear();
                ep.SetError(comboactype, "Please, Complete this field to continue.");
            }
            else if (txtwithdraw.Text == "")
            {

                ep.Clear();
                ep.SetError(txtwithdraw, "Please, Complete this field to continue.");
            }

           
            else
            {
                float withdraw = float.Parse(txtwithdraw.Text);
                float newbal = acc_bal - withdraw;

                DialogResult dialog = MessageBox.Show("Are you sure to continue?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                try
                {
                    if (dialog == DialogResult.Yes)
                    {
                        conn.Open();
                        string querr = ("UPDATE Accounts SET Acc_Balance='" + @newbal + "'");
                        SqlCommand update = new SqlCommand(querr, conn);


                        update.Parameters.AddWithValue("@@newbal", @newbal);


                        int row = update.ExecuteNonQuery();

                        if (row == 1)
                        {

                            //MessageBox.Show("Withdraw Amount :"+withdraw+"/n Current A/C Bal :"+newbal);
                        }
                        else
                        {
                            MessageBox.Show("Withdrwal Successful");
                            MessageBox.Show("Withdraw Amount :" + withdraw + "\n Current A/C Bal :" + newbal);

                        }
                    }
                       

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

                conn.Close();


                btnEnter.Enabled = false;

            }

        }

        private void button36_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage5;
        }

        private void button37_Click(object sender, EventArgs e)
        {
            comboactype.Items.Clear();
            
           
            txtwithdraw.Text = "";
            

        }

        private void button40_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void lbl_value_Click(object sender, EventArgs e)
        {

        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (
                label27.Text == "")
                label27.Text = ("1");
            else
                label27.Text = label27.Text + "1";
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (
                label27.Text == "")
                label27.Text = ("2");
            else
                label27.Text = label27.Text + "2";
        }

        private void button31_Click(object sender, EventArgs e)
        {
            if (
                label27.Text == "")
                label27.Text = ("3");
            else
                label27.Text = label27.Text + "3";
        }

        private void button21_Click(object sender, EventArgs e)
        {
            if (
                label27.Text == "")
                label27.Text = ("4");
            else
                label27.Text = label27.Text + "4";
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (
                label27.Text == "")
                label27.Text = ("5");
            else
                label27.Text = label27.Text + "5";
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (
                label27.Text == "")
                label27.Text = ("6");
            else
                label27.Text = label27.Text + "6";
        }

        private void button24_Click(object sender, EventArgs e)
        {
            if (
                label27.Text == "")
                label27.Text = ("7");
            else
                label27.Text = label27.Text + "7";
        }

        private void button23_Click(object sender, EventArgs e)
        {
            if (
                label27.Text == "")
                label27.Text = ("8");
            else
                label27.Text = label27.Text + "8";
        }

        private void button22_Click(object sender, EventArgs e)
        {
            if (
                label27.Text == "")
                label27.Text = ("9");
            else
                label27.Text = label27.Text + "9";
        }

        private void button32_Click(object sender, EventArgs e)
        {
            if (
                label27.Text == "")
                label27.Text = ("0");
            else
                label27.Text = label27.Text + "0";
        }

        private void button17_Click(object sender, EventArgs e)
        {
            string value = label27.Text;
        }

        private void comboactype_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button25_Click(object sender, EventArgs e)
        {
            label27.Text = "";
        }

        private void button39_Click(object sender, EventArgs e)
        {
            double a, b;
            a = double.Parse(label27.Text);
            b = (a * 184.65);
            label24.Text = b.ToString();
        }

        private void txtacname_TextChanged(object sender, EventArgs e)
        {

        }
        static double ins;
        static double mon;
            static double final;
        private void button45_Click(object sender, EventArgs e)
        {

            try
            {
                double loan_ammount = double.Parse(txtloan.Text);

                double rate = double.Parse(txtrate.Text);

                double number_of_ins = double.Parse(txtnoof.Text);

                ins = loan_ammount / number_of_ins;

                mon = (loan_ammount * rate )* 0.08;

                final = ins + mon;

                txtinloan.Text = final.ToString();
            }
            catch { }
            







        }

        private void button47_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button26_Click(object sender, EventArgs e)
        {
            

            if (comboBox3.Text == "")
            {

                ep.Clear();
                ep.SetError(comboBox3, "Please, Complete this field to continue.");
            }
            else if (txtdeposit.Text == "")
            {

                ep.Clear();
                ep.SetError(txtdeposit, "Please, Complete this field to continue.");
            }
            else
            {
                float deposit = float.Parse(txtdeposit.Text);
                DialogResult dialog = MessageBox.Show("Are you sure to continue?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                try
                {
                    if (dialog == DialogResult.Yes)
                    {
                        float newblanace = acc_bal + deposit;
                        conn.Open();
                        string querr = ("UPDATE Accounts SET Acc_Balance='" + newblanace + "'");
                        SqlCommand update = new SqlCommand(querr, conn);


                        update.Parameters.AddWithValue("@@newblanace", newblanace);


                        int row = update.ExecuteNonQuery();

                        if (row == 1)
                        {

                            //MessageBox.Show("Withdraw Amount :"+withdraw+"/n Current A/C Bal :"+newbal);
                        }
                        else
                        {
                            MessageBox.Show("Deposit Successfull");
                            MessageBox.Show("Withdraw Amount :" + deposit + "\n Current A/C Bal :" + newblanace);

                        }

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

                conn.Close();
            }
        }
    }
}
